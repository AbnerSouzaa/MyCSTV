/* 
Copyright (c) 2022 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Serie : Codable {
	let begin_at : String?
	let description : String?
	let end_at : String?
	let full_name : String?
	let id : Int?
	let league_id : Int?
	let modified_at : String?
	let name : String?
	let season : String?
	let slug : String?
	let tier : String?
	let winner_id : String?
	let winner_type : String?
	let year : Int?

	enum CodingKeys: String, CodingKey {

		case begin_at = "begin_at"
		case description = "description"
		case end_at = "end_at"
		case full_name = "full_name"
		case id = "id"
		case league_id = "league_id"
		case modified_at = "modified_at"
		case name = "name"
		case season = "season"
		case slug = "slug"
		case tier = "tier"
		case winner_id = "winner_id"
		case winner_type = "winner_type"
		case year = "year"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		begin_at = try values.decodeIfPresent(String.self, forKey: .begin_at)
		description = try values.decodeIfPresent(String.self, forKey: .description)
		end_at = try values.decodeIfPresent(String.self, forKey: .end_at)
		full_name = try values.decodeIfPresent(String.self, forKey: .full_name)
		id = try values.decodeIfPresent(Int.self, forKey: .id)
		league_id = try values.decodeIfPresent(Int.self, forKey: .league_id)
		modified_at = try values.decodeIfPresent(String.self, forKey: .modified_at)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		season = try values.decodeIfPresent(String.self, forKey: .season)
		slug = try values.decodeIfPresent(String.self, forKey: .slug)
		tier = try values.decodeIfPresent(String.self, forKey: .tier)
		winner_id = try values.decodeIfPresent(String.self, forKey: .winner_id)
		winner_type = try values.decodeIfPresent(String.self, forKey: .winner_type)
		year = try values.decodeIfPresent(Int.self, forKey: .year)
	}

}