/* 
Copyright (c) 2022 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Json4Swift_Base : Codable {
	let scheduled_at : String?
	let serie_id : Int?
	let live_embed_url : String?
	let end_at : String?
	let videogame_version : String?
	let detailed_stats : Bool?
	let original_scheduled_at : String?
	let league_id : Int?
	let tournament_id : Int?
	let id : Int?
	let modified_at : String?
	let rescheduled : Bool?
	let streams_list : [Streams_list]?
	let begin_at : String?
	let tournament : Tournament?
	let games : [Games]?
	let results : [Results]?
	let streams : Streams?
	let slug : String?
	let live : Live?
	let videogame : Videogame?
	let forfeit : Bool?
	let draw : Bool?
	let status : String?
	let serie : Serie?
	let game_advantage : String?
	let number_of_games : Int?
	let winner : String?
	let league : League?
	let match_type : String?
	let opponents : [Opponents]?
	let winner_id : String?
	let name : String?
	let official_stream_url : String?

	enum CodingKeys: String, CodingKey {

		case scheduled_at = "scheduled_at"
		case serie_id = "serie_id"
		case live_embed_url = "live_embed_url"
		case end_at = "end_at"
		case videogame_version = "videogame_version"
		case detailed_stats = "detailed_stats"
		case original_scheduled_at = "original_scheduled_at"
		case league_id = "league_id"
		case tournament_id = "tournament_id"
		case id = "id"
		case modified_at = "modified_at"
		case rescheduled = "rescheduled"
		case streams_list = "streams_list"
		case begin_at = "begin_at"
		case tournament = "tournament"
		case games = "games"
		case results = "results"
		case streams = "streams"
		case slug = "slug"
		case live = "live"
		case videogame = "videogame"
		case forfeit = "forfeit"
		case draw = "draw"
		case status = "status"
		case serie = "serie"
		case game_advantage = "game_advantage"
		case number_of_games = "number_of_games"
		case winner = "winner"
		case league = "league"
		case match_type = "match_type"
		case opponents = "opponents"
		case winner_id = "winner_id"
		case name = "name"
		case official_stream_url = "official_stream_url"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		scheduled_at = try values.decodeIfPresent(String.self, forKey: .scheduled_at)
		serie_id = try values.decodeIfPresent(Int.self, forKey: .serie_id)
		live_embed_url = try values.decodeIfPresent(String.self, forKey: .live_embed_url)
		end_at = try values.decodeIfPresent(String.self, forKey: .end_at)
		videogame_version = try values.decodeIfPresent(String.self, forKey: .videogame_version)
		detailed_stats = try values.decodeIfPresent(Bool.self, forKey: .detailed_stats)
		original_scheduled_at = try values.decodeIfPresent(String.self, forKey: .original_scheduled_at)
		league_id = try values.decodeIfPresent(Int.self, forKey: .league_id)
		tournament_id = try values.decodeIfPresent(Int.self, forKey: .tournament_id)
		id = try values.decodeIfPresent(Int.self, forKey: .id)
		modified_at = try values.decodeIfPresent(String.self, forKey: .modified_at)
		rescheduled = try values.decodeIfPresent(Bool.self, forKey: .rescheduled)
		streams_list = try values.decodeIfPresent([Streams_list].self, forKey: .streams_list)
		begin_at = try values.decodeIfPresent(String.self, forKey: .begin_at)
		tournament = try values.decodeIfPresent(Tournament.self, forKey: .tournament)
		games = try values.decodeIfPresent([Games].self, forKey: .games)
		results = try values.decodeIfPresent([Results].self, forKey: .results)
		streams = try values.decodeIfPresent(Streams.self, forKey: .streams)
		slug = try values.decodeIfPresent(String.self, forKey: .slug)
		live = try values.decodeIfPresent(Live.self, forKey: .live)
		videogame = try values.decodeIfPresent(Videogame.self, forKey: .videogame)
		forfeit = try values.decodeIfPresent(Bool.self, forKey: .forfeit)
		draw = try values.decodeIfPresent(Bool.self, forKey: .draw)
		status = try values.decodeIfPresent(String.self, forKey: .status)
		serie = try values.decodeIfPresent(Serie.self, forKey: .serie)
		game_advantage = try values.decodeIfPresent(String.self, forKey: .game_advantage)
		number_of_games = try values.decodeIfPresent(Int.self, forKey: .number_of_games)
		winner = try values.decodeIfPresent(String.self, forKey: .winner)
		league = try values.decodeIfPresent(League.self, forKey: .league)
		match_type = try values.decodeIfPresent(String.self, forKey: .match_type)
		opponents = try values.decodeIfPresent([Opponents].self, forKey: .opponents)
		winner_id = try values.decodeIfPresent(String.self, forKey: .winner_id)
		name = try values.decodeIfPresent(String.self, forKey: .name)
		official_stream_url = try values.decodeIfPresent(String.self, forKey: .official_stream_url)
	}

}