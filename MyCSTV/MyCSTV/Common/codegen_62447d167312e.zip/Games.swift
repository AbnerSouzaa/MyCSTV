/* 
Copyright (c) 2022 Swift Models Generated from JSON powered by http://www.json4swift.com

Permission is hereby granted, free of charge, to any person obtaining a copy of this software and associated documentation files (the "Software"), to deal in the Software without restriction, including without limitation the rights to use, copy, modify, merge, publish, distribute, sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

For support, please feel free to contact me at https://www.linkedin.com/in/syedabsar

*/

import Foundation
struct Games : Codable {
	let begin_at : String?
	let complete : Bool?
	let detailed_stats : Bool?
	let end_at : String?
	let finished : Bool?
	let forfeit : Bool?
	let id : Int?
	let length : String?
	let match_id : Int?
	let position : Int?
	let status : String?
	let video_url : String?
	let winner : Winner?
	let winner_type : String?

	enum CodingKeys: String, CodingKey {

		case begin_at = "begin_at"
		case complete = "complete"
		case detailed_stats = "detailed_stats"
		case end_at = "end_at"
		case finished = "finished"
		case forfeit = "forfeit"
		case id = "id"
		case length = "length"
		case match_id = "match_id"
		case position = "position"
		case status = "status"
		case video_url = "video_url"
		case winner = "winner"
		case winner_type = "winner_type"
	}

	init(from decoder: Decoder) throws {
		let values = try decoder.container(keyedBy: CodingKeys.self)
		begin_at = try values.decodeIfPresent(String.self, forKey: .begin_at)
		complete = try values.decodeIfPresent(Bool.self, forKey: .complete)
		detailed_stats = try values.decodeIfPresent(Bool.self, forKey: .detailed_stats)
		end_at = try values.decodeIfPresent(String.self, forKey: .end_at)
		finished = try values.decodeIfPresent(Bool.self, forKey: .finished)
		forfeit = try values.decodeIfPresent(Bool.self, forKey: .forfeit)
		id = try values.decodeIfPresent(Int.self, forKey: .id)
		length = try values.decodeIfPresent(String.self, forKey: .length)
		match_id = try values.decodeIfPresent(Int.self, forKey: .match_id)
		position = try values.decodeIfPresent(Int.self, forKey: .position)
		status = try values.decodeIfPresent(String.self, forKey: .status)
		video_url = try values.decodeIfPresent(String.self, forKey: .video_url)
		winner = try values.decodeIfPresent(Winner.self, forKey: .winner)
		winner_type = try values.decodeIfPresent(String.self, forKey: .winner_type)
	}

}